#!/bin/bash

rmiregistry &
sleep 2
java AuctionServer
